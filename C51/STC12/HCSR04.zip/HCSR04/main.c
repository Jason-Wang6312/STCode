#include "STC12C5A.H"
#include "LCD1602.H"
#include "HC_SR04.H"

unsigned int cnt = 0;
void Time0Init();
void distance();

void main(){
	unsigned char diststr[] = "D:0.00M";
	
	Time0Init();
	HCSR04Init();
	LCDInit();
	EA = 1;
	
	LCDShowStr(0,1,diststr);
	
	while(1){
		if(cnt > 1000){
			cnt = 0;
			distance();
			P22 = ~P22;
		}
	}
}

void distance(){
	unsigned int distance;
	unsigned char disstr[] = "0.00";
	
	distance = getDistance();
	disstr[0] = (distance * 0.01) + '0';
	disstr[2] = ((distance % 100) / 10) + '0';
	disstr[3] = (distance % 10) + '0';
	LCDShowStr(2,1,disstr);
}

void Time0Init(){
	AUXR |= 0x40;
	TMOD &= 0x0F;
	TMOD |= 0x10;
	TL1 = 0x20;
	TH1 = 0xD1;
	TF1 = 0;
	TR1 = 1;
	ET1 = 1; 
}

void time0() interrupt 3{
	TL1 = 0x20;
	TH1 = 0xD1;
	cnt++;
}

