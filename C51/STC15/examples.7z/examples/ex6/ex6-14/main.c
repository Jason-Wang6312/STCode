#include<STC15F2K.h>
#include <stdio.h>
sbit SD_CS    = P1^4;	
sbit SD_CLK   = P1^0;	
sbit SD_DO    = P1^1;
sbit SD_DI    = P1^2;
#define CR 0x0D        
#define uchar unsigned char        
#define uint  unsigned int        
#define ulong unsigned long

uchar xdata buf1[512];
uchar xdata buf2[30];

/********************** дһ�ֽڵ�SD��,ģ��SPI���߷�ʽ *****************************/
void SdWrite(uchar n){
	uchar i;
	for(i=8;i;i--){
		SD_CLK=0;
		SD_DI=(n&0x80);
		n<<=1;
		SD_CLK=1;
	}	
	SD_CLK=0;
}

/************************* ��SD����һ�ֽ�,ģ��SPI���߷�ʽ ***************************/
uchar SdRead(){
	uchar n,i;
	for(i=8;i;i--){
		SD_CLK=0;
		SD_CLK=1;
		n<<=1;
		if(SD_DO) n|=1;
	}
	return n;
}

/***************************** ���SD������Ӧ **********************************/
uchar SdResponse(){
	uchar i=0,response;
	while(i<=8){
		response = SdRead();
		if(response==0x00) break;
		if(response==0x01) break;
		i++;
	}
	return response;
} 

/***************************** �����SD�� **********************************/
void SdCommand(uchar command, unsigned long argument, uchar CRC){
	SdWrite(command|0x40);
	SdWrite(((uchar *)&argument)[0]);
	SdWrite(((uchar *)&argument)[1]);
	SdWrite(((uchar *)&argument)[2]);
	SdWrite(((uchar *)&argument)[3]);
	SdWrite(CRC);
}

/***************************** ��ʼ��SD�� **********************************/
uchar SdInit(void){
	int delay=0, trials=0;
	uchar i;
	uchar response=0x01;
	SD_CS=1;
	for(i=0;i<=9;i++) SdWrite(0xff);
	SD_CS=0;
	SdCommand(0x00,0,0x95);
	response=SdResponse();
	if(response!=0x01) return 0;
	while(response==0x01){
		SD_CS=1;
		SdWrite(0xff);
		SD_CS=0;
		SdCommand(0x01,0x00,0xff);
		response=SdResponse();
	} 
	SD_CS=1;
	SdWrite(0xff);
	return 1; 
}

/************************ ��SD��ָ����ַд����,һ�����512�ֽ� *************************/
uchar SdWriteBlock(uchar *Block, ulong address,int len){
	uint count;
	uchar dataResp;
  	printf("SD_Write_block");
   	SD_CS=0;
    SdCommand(0x18,address,0xff);
   	if(SdResponse()==00) {
     	SdWrite(0xff);
     	SdWrite(0xff);
     	SdWrite(0xff);
     	SdWrite(0xfe);
       	for(count=0;count<len;count++) SdWrite(*Block++);
     	for(;count<512;count++) SdWrite(0);
        SdWrite(0xff); 		//���ֽ�CRCУ��, Ϊ0xFFFF ��ʾ������CRC
     	SdWrite(0xff);
     	dataResp=SdRead();
        while(SdRead()==0);
      	dataResp=dataResp&0x0f; 
      	SD_CS=1;
      	SdWrite(0xff);
      	if(dataResp==0x0b){
	        printf("DATA WAS NOT ACCEPTED BY CARD -- CRC ERROR\n");
	    	return 0;
        }
       	if(dataResp==0x05){
        	printf("    Write OK\n");
			return 1;
		}
        printf("Invalid data Response token.\n");
        return 0;
     }
     printf("Command 0x18 (Write) was not received by the SD.\n");
     return 0;
}

/***********************��SD��ָ����ַ��ȡ����,һ�����512�ֽ�*************************/
uchar SdReadBlock(uchar *Block, ulong address,int len){
 	uint count;
  	printf("SD_read_block");
	SD_CS=0;
    SdCommand(0x11,address,0xff);
    if(SdResponse()==00) {
        while(SdRead()!=0xfe);
        for(count=0;count<len;count++) *Block++=SdRead(); 
        for(;count<512;count++) SdRead();
        SdRead();
        SdRead();
        SD_CS=1;
        SdRead();
        printf("     Read Data as Follows\n");
		return 1;
   }
   printf("Command 0x11 (Read) was not received by the SD.\n");
   return 0;
}

/******************************* ������ *******************************/
void main(void){   
   int i,j; uchar SD;
   CLK_DIV=0x03;			//STC15��Ƶ�������봫ͳ8051����
   SCON=0x52;TMOD=0x20;  	// ���пڡ���ʱ����ʼ�� 
   PCON=0x80;TH1=0x0F3;  	//fosc=12MHz,������=4800
   TL1=0x0F3;TCON=0x69;
   SD=SdInit();
   if(SD==0){ 
   		printf("SD Card Error\n");
		while(1);
   }
   for(i=0;i<512;i++) { 			//��д������װ�뻺����
   		buf1[i]=i;
   }
   SdWriteBlock(buf1,0x00,512);		//д��ַΪ0x00�Ĵ洢�飬��СΪ512�ֽ�
   for(i=0;i<512;i++) { 
	 	buf1[i]=0;
	}
   SdReadBlock (buf1,0x00,512);   	//����ַΪ0x00�Ĵ洢�飬 ��СΪ512�ֽ�
   for(i=0;i<0x20;i++) { 		  	//��ȡ������ͨ�����п����
		for(j=0; j<0x10; j++){
	   		printf("%4bX",buf1[(i<<4)+j]); 
		}
	   	printf("%\n");
   }

   SdWriteBlock("THE SD READ/WRITE TEST OK!",0x000200,26);//д���ַ���
   SdReadBlock (buf2,0x000200,26);   //�������м���
   for(i=0;i<1;i++) { 
		for(j=0; j<0x10; j++){
	   		printf("%4bX",buf2[(i<<4)+j]);
		}
   		printf("%\n");
   }
   printf("  %s",buf2);
   while(1);
 }


