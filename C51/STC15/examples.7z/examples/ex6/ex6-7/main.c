#include <STC15F2K.h>
unsigned char temp;
unsigned char key;
unsigned char i,j;
unsigned char STH0;
unsigned char STL0;
unsigned int code tab[]=      //������
{64021,64103,64260,64400,
64524,64580,64684,64777,
64820,64898,64968,65030,
65058,65110,65157,65178};

void main(void){			  //������
	TMOD=0x01;
	ET0=1;
	EA=1;
	while(1){
		P3=0xff;
		P34=0;
		temp=P3;
		temp=temp & 0x0f;
		if (temp!=0x0f)	{		  //�ӵ�һ�п�ʼɨ�����
			for(i=50;i>0;i--)	  //��ʱ��������
			for(j=200;j>0;j--);
			temp=P3;
			temp=temp & 0x0f;
			if (temp!=0x0f){
				temp=P3;
				temp=temp & 0x0f;
				switch(temp){	 //��ȡ����ֵ
					case 0x0e:
						key=0;
						break;
					case 0x0d:
						key=1;
						break;
					case 0x0b:
						key=2;
						break;
					case 0x07:
						key=3;
						break;
				}
				temp=P3;
				P10=~P10;
				STH0=tab[key]/256;	//����������Ӧ�Ķ�ʱ������ֵ
				STL0=tab[key]%256;
				TR0=1;
				temp=temp & 0x0f;
				while(temp!=0x0f){
					temp=P3;
					temp=temp & 0x0f;
				}
			TR0=0;
			}
		}

		P3=0xff;
		P35=0;
		temp=P3;
		temp=temp & 0x0f;
		if (temp!=0x0f){   			//ɨ����̵ڶ���
			for(i=50;i>0;i--)
			for(j=200;j>0;j--);
			temp=P3;
			temp=temp & 0x0f;
			if (temp!=0x0f){
				temp=P3;
				temp=temp & 0x0f;
				switch(temp){
					case 0x0e:
						key=4;
						break;
					case 0x0d:
						key=5;
						break;
					case 0x0b:
						key=6;
						break;
					case 0x07:
						key=7;
						break;
				}
				temp=P3;
				P10=~P10;
				STH0=tab[key]/256;
				STL0=tab[key]%256;
				TR0=1;
				temp=temp & 0x0f;
				while(temp!=0x0f){
					temp=P3;
					temp=temp & 0x0f;
				}
				TR0=0;
			}
		}

		P3=0xff;
		P36=0;
		temp=P3;
		temp=temp & 0x0f;
		if (temp!=0x0f){			//ɨ����̵�����
			for(i=50;i>0;i--)
			for(j=200;j>0;j--);
			temp=P3;
			temp=temp & 0x0f;
			if (temp!=0x0f){
				temp=P3;
				temp=temp & 0x0f;
				switch(temp){
					case 0x0e:
						key=8;
						break;
					case 0x0d:
						key=9;
						break;
					case 0x0b:
						key=10;
						break;
					case 0x07:
						key=11;
						break;
				}
				temp=P3;
				P10=~P10;
				STH0=tab[key]/256;
				STL0=tab[key]%256;
				TR0=1;
				temp=temp & 0x0f;
				while(temp!=0x0f){
					temp=P3;
					temp=temp & 0x0f;
				}
				TR0=0;
			}
		}

		P3=0xff;
		P37=0;
		temp=P3;
		temp=temp & 0x0f;
		if (temp!=0x0f){			 //ɨ����̵�����
			for(i=50;i>0;i--)
			for(j=200;j>0;j--);
			temp=P3;
			temp=temp & 0x0f;
			if (temp!=0x0f){
				temp=P3;
				temp=temp & 0x0f;
				switch(temp){
					case 0x0e:
						key=12;
						break;
					case 0x0d:
						key=13;
						break;
					case 0x0b:
						key=14;
						break;
					case 0x07:
						key=15;
						break;
				}
				temp=P3;
				P10=~P10;
				STH0=tab[key]/256;
				STL0=tab[key]%256;
				TR0=1;
				temp=temp & 0x0f;
				while(temp!=0x0f){
					temp=P3;
					temp=temp & 0x0f;
				}
				TR0=0;
			}
		}
	}
}

void t0(void) interrupt 1 using 0 {     //��ʱ��T0�жϷ�����
	TH0=STH0;
	TL0=STL0;
	P10=~P10;				  //��������
} 