#include	"delay.h"
/*********************** ������ʱ���� **************************/
void  delay_ms(unsigned char ms){
     unsigned int i;
	 do{
	      i = MAIN_Fosc / 13000;
		  while(--i);   
     }while(--ms);
}
