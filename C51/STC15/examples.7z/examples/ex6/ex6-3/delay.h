#ifndef	__DELAY_H
#define	__DELAY_H

#include	"config.h"

void  delay_ms(uchar ms);

#endif
