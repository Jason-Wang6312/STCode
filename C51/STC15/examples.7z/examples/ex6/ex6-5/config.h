#ifndef		__CONFIG_H
#define		__CONFIG_H
#define MAIN_Fosc	22118400L	//������ʱ��
#define uchar		unsigned char
#define uint		unsigned int
#define ulong		unsigned long
#define DIS_DOT		0x20
#define DIS_BLACK	0x10
#define DIS_		0x11
#endif
