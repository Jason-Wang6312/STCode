/************************************************************************

                   3��4����������뺯���� 

************************************************************************/      
#include<absacc.h>
#include<intrins.h>
#define uchar unsigned char
#define uint unsigned int

uchar idata com1,com2;

/************************** ����ɨ�躯�� **********************/
uchar key_scan() {
   uchar temp;
   uchar com;
   P1=0xf0;
   if(P1!=0xf0) {
        com1=P1;
        P1=0x0f;
        com2=P1;        
   }
	P1=0xf0;
    while(P1!=0xf0);	  
	temp=com1|com2;
	if(temp==0xee)com=0x01;		//����
	if(temp==0xed)com=0x02;
	if(temp==0xeb)com=0x03;
	if(temp==0xde)com=0x04;
	if(temp==0xdd)com=0x05;
	if(temp==0xdb)com=0x06;
	if(temp==0xbe)com=0x07;
	if(temp==0xbd)com=0x08;
	if(temp==0xbb)com=0x09;
	if(temp==0x7e)com=0x0a;		//CLR
	if(temp==0x7d)com=0x00;
	if(temp==0x7b)com=0x0b;		//����빦��Ϊ�������������ȷ��  
	return(com);
}
