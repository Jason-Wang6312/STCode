
typedef unsigned char uchar;
typedef unsigned int uint ;

uchar help();
uchar inport( uchar idata *buf );
uchar outport( uchar idata *buf );
uchar command( uchar idata *buf );

#define XTAL	20e6
#define BAUD	4800
#define SMOD_ 	0x80
#define	RXD_	0x01
#define	TXD_	0x02
#define TI_		0x02
#define REN_ 	0x10
#define	SM1_	0x40
#define T1_M1_	0x20

