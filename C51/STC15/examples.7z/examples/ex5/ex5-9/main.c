
#include<STC15F2K.h>
#include<pic.h>
#define uchar unsigned char
#define uint unsigned int
#define PORT P0

sbit CS1=P2^4;
sbit CS2=P2^3;
sbit RS=P2^0;
sbit RW=P2^1;
sbit E=P2^2;
sbit bflag=P0^7;

/**************************** ��ʱ���� ************************************/
void	delay(void){
	uchar	i=6;
	while(--i)	;
}

/**************************** ����� ************************************/
void Left(){
	CS1=0; CS2=1;

}
/**************************** �Ұ��� ************************************/
void Right(){
	CS1=1; CS2=0;
}

/****************************** ��æ **************************************/
void Busy_12864(){
	do{
		E=0; RS=0;RW=1;delay();
		PORT=0xff;delay();
		E=1;delay();E=0;} while(bflag);
}

/**************************** ����д�� ************************************/
void Wreg(uchar c){
	Busy_12864();
	RS=0; RW=0;delay();
	PORT=c;delay();
	E=1; delay(); E=0;
}

/**************************** ����д�� ************************************/
void Wdata(uchar c){
	Busy_12864();
	RS=1; RW=0;delay();
	PORT=c;delay();
	E=1; delay(); E=0;
}

/**************************** ������ʾ��ʼҳ *******************************/
void Pagefirst(uchar c){
 	uchar i=c;
	c=i|0xb8;
	Busy_12864();
	Wreg(c);
}

/**************************** ������ʾ��ʼ�� *******************************/
void Columnfirst(uchar c){
	uchar i=c;
	c=i|0x40;
	Busy_12864();
	Wreg(c);
}

/********************************* ���� ************************************/
void Ready_12864(){		        	  
   	uint i,j;
   	Left();
   	Wreg(0x3f);
   	Right();
   	Wreg(0x3f);
   	Left();
   	for(i=0;i<8;i++){
		Pagefirst(i);
		Columnfirst(0x00);
		for(j=0;j<64;j++){
			Wdata(0x00);
		}
   	}
   	Right();
   	for(i=0;i<8;i++){
		Pagefirst(i);
		Columnfirst(0x00);
		for(j=0;j<64;j++){
		  	Wdata(0x00);
		}
   	}
}

/************************** 16��16�ĺ�����ʾ������ȡģ���ֽڵ��� ************************/
void DisHZ(uchar *s,uchar page,uchar Column){		  
	uchar i,j;
	Pagefirst(page);
	Columnfirst(Column);
	for(i=0;i<16;i++){
		Wdata(*s); s++;
	}
	Pagefirst(page+1);
	Columnfirst(Column);
	for(j=0;j<16;j++){
		Wdata(*s); s++;
	}
}
/************************************* ѡ�� *********************************/
void SelectScreen(uchar screen) { 
   switch(screen) {
      case 0:
         CS1=0;	CS2=0;	//ȫ��
         break;
      case 1:
         CS1=1;	CS2=0;	//����
         break;
      case 2:
         CS1=0;	CS2=1;		//����
         break;
      default:
         break;
   }
}

/**************************** �趨�е�ַ(ҳ) **********************************/
void SetLine(uchar line)
{
   line &= 0x07; // 0<=line<=7
   line |= 0xb8; //1011 1xxx
   Wreg(line);
}
/**************************** �趨�е�ַ **************************************/
void SetColumn(uchar column) {
   column &= 0x3f; // 0=<column<=63
   column |= 0x40; //01xx xxxx
   Wreg(column);
}


/******************************* ��ʾͼƬ���� ****************************************/		  
void DisPic(uchar lin, uchar column, uchar high, uchar width, uchar *address){
   uchar i, j;
   if(column<64) {
      for(j=0;j<high;j+=8) {
      	 SelectScreen(2); 			//�������<64��ӵ�һ���Ͽ�ʼд
         SetLine(lin);
         SetColumn(column);
         for(i=0;i<width;i++){
            if(i+column>127)
               break;
            if(column+i<64){
               Wdata(*(address+i));
            }
            else {
               SelectScreen(1);
               SetLine(lin);
               SetColumn(column-64+i);
               Wdata(*(address+i));
            }
         }
         lin+=1;
         address+=width;
      }
   }
   else {
      column-=64; 					//��ֹԽ��
      for(j=0;j<high;j+=8) {
      	 SelectScreen(2); 			//����ӵڶ����Ͽ�ʼд
         SetLine(lin);
         SetColumn(column);
         for(i=0;i<width;i++) {
         	 if(i+column>64)
               break;
            if(column+i<64) {
               Wdata(*(address+i));
            }
            else {
               SelectScreen(1);
               SetLine(lin);
               SetColumn(column-64+i);
               Wdata(*(address+i));
            }
         }
         lin+=1;
         address+=width;
     }
   }
}

/****************************** ������ ****************************************/
main(){
	uint i=0x0ffff;
	Ready_12864();
	Left();
	DisHZ(Num,0x03,0);		     	//��ʾ����
	DisHZ(Num+32,0x03,16);
	DisHZ(Num+64,0x03,32);
	DisHZ(Num+96,0x03,48);
	Right();
	DisHZ(Num+128,0x03,64);
	DisHZ(Num+160,0x03,80);
	DisHZ(Num+192,0x03,96);
	DisHZ(Num+224,0x03,112);
	while(i--);					  	//��ʱ
	Ready_12864();
	DisPic(1, 13, 48, 101,Pic);		//��ʾͼƬ
	while(1);
}