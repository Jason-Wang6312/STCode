#include<STC15F2K.h> 
#include<intrins.h>
#define uchar unsigned char

uchar code table[]={0x3f,0x06,0x5b,0x4f,0x66, //�����
					 0x6d,0x7d,0x07,0x7f,0x6f};

/****************************** ��ʱ���� ******************************/
void delay(){				//2ms@12MHz
	uchar i, j;
	i = 24;	j = 85;
	do{
		while (--j);
	} while (--i);}
	 
/*******************************������ ********************************/
main(){  
   	while(1){
		uchar i;
		P3=0x7f;
		for(i=0;i<8;i++){
			P3=_crol_(P3,1);			
			P0=table[i];
			delay();
		}
	}
}
