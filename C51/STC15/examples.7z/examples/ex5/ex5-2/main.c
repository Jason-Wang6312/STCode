#include <STC15F2K.h>
#include <intrins.h>
#define uchar unsigned char

sbit SH_CP  =  P3^0;
sbit DS	    =  P3^1;
sbit ST_CP  =  P3^2;
#define NOP  _nop_()

uchar ledcode[] ={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
uchar ledbitselect[] = {0x0fe,0xfd,0xfb,0xf7,0xef,0xdf,0xbf,0x7f};

uchar i;

void InitSerialPort(void){
  DS = 0;
  SH_CP = 0;
  ST_CP = 0;
}

void delay(void){
	uchar jj;
	for(jj=0;jj<200;jj++);
	while(jj--);
}

void SerialSendData(uchar dat){
  uchar ii;
  uchar DSta=dat;
  for(ii=0;ii<8;ii++){
    if(DSta&0x80)DS=1;
	else DS = 0;
    DSta<<=1;
    SH_CP =0;
    NOP; NOP;NOP; NOP;
    SH_CP = 1;
    NOP; NOP;
  }
  ST_CP = 1;
  NOP; NOP;NOP; NOP;
  ST_CP = 0;
}

void main(){
  InitSerialPort();
  while(1){
	  delay();
	  delay();
	  P2 = ledbitselect[i];
	  SerialSendData(ledcode[i]);
	  i=(i+1)%8;
  }
}