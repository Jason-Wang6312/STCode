#include <STC15F2K.h>
#include <intrins.h>
#define uchar unsigned char
#define uint unsigned int 

uchar dspBf[8]={0,1,2,3,4,5,6,7};  //��ʾ������
uchar code SEG[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07, //�����
					0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71,0x00};

/* �������ʾ���� */
void disp(){		
   	uchar i,dmask=0xfe;
	for(i=0;i<8;i++){
		P2=0xff; 	  //Ϩ������LED
		P0=SEG[dspBf[i]]; 	  
		P2=dmask; 	  
      	dmask=_crol_(dmask,1);   //�޸�ɨ��ģʽ 
	}
}

/* ����ɨ�躯�� */
uchar key(){		
   	uchar i,kscan;
	uchar temp=0x00,kval=0x00,kmask=0xfe;
	for(i=0;i<4;i++){
		P3=kmask; 	     	//ɨ��ģʽ��P3��
		kscan=P3;          	//��P3�� 
		kscan=kscan>>4;          	 
		switch(kscan&0x0f){
			case(0x0e):kval=0x00+temp; break;
			case(0x0d):kval=0x01+temp; break;
			case(0x0b):kval=0x02+temp; break;
			case(0x07):kval=0x03+temp; break;
			default:
				kmask=_crol_(kmask,1); //�޸�ɨ��ģʽ
				temp=temp+0x04; break;
		}
	}
	if(kmask==0xef) kval=0x088;   
	return kval;
}

void main(){
   	uchar i,k;
	while(1){
		disp(); 
		k=key();
		if(k!=0x88){
			dspBf[0]=k;
			for(i=1;i<8;i++){
				dspBf[i]=0x10;
			}			
		} 
		disp();
	}		   
}  
