
#define SLAW	0xA2
#define SLAR	0xA3
#define uchar	unsigned char
#define uint	unsigned int
#define DIS_DOT		0x20
#define DIS_BLACK	0x10
#define DIS_		0x11

void	WriteNbyte(uchar addr, uchar *p, uchar number);
void	ReadNbyte( uchar addr, uchar *p, uchar number);

