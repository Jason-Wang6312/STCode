#include <STC15F2K.H>
#include <stdio.h>
struct ydate  {
    unsigned int year;
    unsigned char month, day;
};

leapyear(struct ydate d)  {
    unsigned char leapy=0;
    if((d.year%4==0 && d.year%100!=0)||d.year%400==0)
      leapy=1;
    return(leapy);
}

numdays(struct ydate d)  {
    unsigned char day;
    static char daytab[]=
      {31,28,31,30,31,30,31,31,30,31,30,31};
    if(leapyear(d)&&d.month==2)
      day=29;
    else
      day=daytab[d.month-1];
    return(day);
}

main()  {
    struct ydate today, tomorrow;
    SCON=0x52;              		//���ô��пڹ�����ʽ
    AUXR &= 0xFE;					//ѡ��ʱ��1Ϊ�����ʷ�����
    TMOD=0x20;					//��T1��Ϊ������ʽ2,12T��ʽ
    TH1=TL1=0xf3;PCON=0x80; 	     //���ò�����=4800@12MHz  
    TR1=1;						//����T1
    printf("Please enter today's date(mm,dd,yyyy):\n");
    scanf("%bd,%bd,%d",&today.month,&today.day,&today.year);
    if(today.day!=numdays(today))  {
      tomorrow.day=today.day+1;
      tomorrow.month=today.month;
      tomorrow.year=today.year;
    }
    else
     if(today.month==12)  {
       tomorrow.day=1;
       tomorrow.month=1;
       tomorrow.year=today.year+1;
     }
    else  {
       tomorrow.day=1;
       tomorrow.month=today.month+1;
       tomorrow.year=today.year;
     }
    printf("Tomorrow's date is %bd/%bd/%d. \n",tomorrow.month,
              tomorrow.day, tomorrow.year);
    while(1);
}
