#include <reg51.h>
 int dtime1=0x0a;
 sbit LED=P1^0;
 
void timer0 () interrupt 1 using 3 {
   TH0=0x3c;
   TL0=0xB0;
   if (--dtime1==0) {
      dtime1=0x0a;
      LED=~LED;
     }
  }

void main() {
  TMOD=0x01;
  TH0=0x3c;
  TL0=0xb0; 
  IE=0x82; 
  TR0=1;             
  while(1);          
}
