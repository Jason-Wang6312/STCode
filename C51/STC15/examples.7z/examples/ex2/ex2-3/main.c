#include <reg51.h>
char code seg[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};
void dsp(char digt, j)  {
     unsigned char tmp;
     SBUF=seg[digt];
     P1=j;
     tmp=0x7f;
     while(tmp--);
}

void main()  {
    SCON=0x00;
    while(1) {
      dsp(0x08, 1);
      dsp(0x00, 2);
      dsp(0x05, 4);
      dsp(0x01, 8);
    }
}
