#include <STC15F2K.H>
char xdata * px;
 char idata * pi;
 char code * pc;
 char c;
 int i;
 void main(void)  {
   pc=(void *) main;
   pi=(char idata *)&i;
   pi=(char idata *)px;
   pc=(char code *)0x7788;

   c=*((char code *)0x8000); 	          /* char [code[0x8000]] */
   c+=*((char xdata *)0xff00);	          /* char [xdata[0xFF00]] */
   c+=*((char idata *)0xf0);		  		/* char [idata[0xF0]] */
   c+=*((char pdata *)0xf0);		  		/* char [pdata[0xF0]] */

   i=*((int code *)0x1200);	          	/* int from code[0x1200] */
   px=*((char xdata *xdata *)0x4000);    /* x-ptr from xdata[0x4000] */
   px=((char xdata *xdata *)0x4000)[0];  /* same as before */
   px=((char xdata *xdata *)0x4000)[1];  /* x-ptr from xdata[0x4002] */
	 
   i=((int (code *)(void))0xff00)();      /* LCALL 0FF00H */
}
